<?php

define('DBHOST', 'localhost');
define('DBNAME', 'id9452177_store');
define('DBUSER', 'id9452177_choudarystore');
define('DBPASSWORD', 'choudarystore');
